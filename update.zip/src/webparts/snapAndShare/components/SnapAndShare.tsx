import * as React from "react";
import { ISnapAndShareProps } from "./ISnapAndShareProps";
import "../../../styles/dist/tailwind.css";
import CreatePost from "./childs/CreatePost";
import { sp } from "@pnp/sp/presets/all";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faThumbsUp,
  faComment,
  faShare,
} from "@fortawesome/free-solid-svg-icons";

interface ISnapAndShareState {
  posts: {
    id: number;
    title: string;
    imageUrl: string;
    caption: string;
    user: string;
    avatarUrl: string;
  }[];
  showToast: boolean;
  toastMessage: string;
}

interface IPost {
  ID: number;
  Title: string;
  PostedBy: {
    EMail: string;
    Title: string;
  };
  PostLikedBy?: string;
}

interface IImage {
  FileLeafRef: string;
  PostID: number;
  FileRef: string;
}

export default class SnapAndShare extends React.Component<
  ISnapAndShareProps,
  ISnapAndShareState
> {
  constructor(props: ISnapAndShareProps) {
    super(props);
    this.state = {
      posts: [],
      showToast: false,
      toastMessage: "",
    };
    sp.setup({
      spfxContext: this.props.context,
      sp: { headers: { Accept: "application/json; odata=nometadata" } },
    });
    this.handlePostCreate = this.handlePostCreate.bind(this);
    this.closeToast = this.closeToast.bind(this);
  }

  /**
   * Fetches posts and images from SharePoint lists.
   * Updates the state with posts and their associated images.
   */
  public componentDidMount(): void {
    this.loadPostsAndImages().catch((error) => {
      console.error("Error loading posts and images: ", error);
    });
  }

  /**
   * Displays a toast message for 3 seconds.
   * @param message - The message to be displayed in the toast.
   */
  private showToast(message: string): void {
    this.setState({
      showToast: true,
      toastMessage: message,
    });
    setTimeout(() => this.closeToast(), 3000);
  }

  /**
   * Closes the currently open toast message.
   */
  private closeToast(): void {
    this.setState({
      showToast: false,
      toastMessage: "",
    });
  }

  /**
   * Loads posts from 'SnapAndSharePosts' list and their images from 'SnapAndShareImages' list.
   * Maps posts with their corresponding images and updates the state.
   */
  private async loadPostsAndImages(): Promise<void> {
    try {
      // Fetch posts from SnapAndSharePosts list
      const posts: IPost[] = await sp.web.lists
        .getByTitle("SnapAndSharePosts")
        .items.select(
          "ID",
          "Title",
          "PostedBy/Title",
          "PostedBy/EMail",
          "PostLikedBy"
        )
        .orderBy("ID", false) // Order by ID descending to show latest posts first
        .expand("PostedBy")
        .get();

      // Fetch images from SnapAndShareImages library
      const images: IImage[] = await sp.web.lists
        .getByTitle("SnapAndShareImages")
        .items.select("FileLeafRef", "PostID", "FileRef")
        .get();

      // Group images by PostID
      const imagesByPostId: { [key: number]: IImage[] } = images.reduce(
        (acc: { [key: number]: IImage[] }, image) => {
          if (!acc[image.PostID]) {
            acc[image.PostID] = [];
          }
          acc[image.PostID].push(image);
          return acc;
        },
        {}
      );

      // Combine posts and images, setting the first image as the default image for each post
      const postsWithImages = posts.map((post) => {
        const postedBy = post.PostedBy ? post.PostedBy.Title : "Unknown User";
        const userEmail = post.PostedBy ? post.PostedBy.EMail : "";

        // Set the user avatar
        const userAvatar = userEmail
          ? `${this.props.context.pageContext.web.absoluteUrl}/_layouts/15/userphoto.aspx?size=S&email=${userEmail}`
          : `${this.props.context.pageContext.web.absoluteUrl}/_layouts/15/images/person.png`;

        // Get images for the current post
        const postImages = imagesByPostId[post.ID] || [];
        const firstImage = postImages.length > 0 ? postImages[0].FileRef : ""; // Use the first image as the default image

        return {
          id: post.ID,
          title: post.Title,
          imageUrl: firstImage,
          caption: post.Title,
          user: postedBy,
          avatarUrl: userAvatar,
          images: postImages.map((img) => img.FileRef), // Include all images for the post
        };
      });

      // Set the state with the posts and their associated images
      this.setState({ posts: postsWithImages });
    } catch (error) {
      console.error("Error loading posts and images: ", error);
    }
  }

  /**
   * Handles creating a new post by uploading images and adding metadata to SharePoint.
   * @param caption - The caption for the post.
   * @param images - The array of images to be uploaded.
   */
  private async handlePostCreate(
    caption: string,
    images: File[]
  ): Promise<void> {
    if (!caption || images.length === 0) {
      this.showToast("Please provide a caption and at least one image.");
      return;
    }

    try {
      const addedPost = await sp.web.lists
        .getByTitle("SnapAndSharePosts")
        .items.add({
          Title: caption,
          PostedById: this.props.context.pageContext.legacyPageContext.userId,
        });

      const postId = addedPost.data.ID;

      for (const image of images) {
        const fileName = image.name;
        const fileArrayBuffer = await image.arrayBuffer();

        await sp.web
          .getFolderByServerRelativeUrl(
            "/sites/Intranet_Site/SnapAndShareImages"
          )
          .files.add(fileName, fileArrayBuffer, true)
          .then((file) => {
            return file.file.getItem(); // Return the item for the next `.then()`
          })
          .then((item) => {
            return item.update({
              PostID: postId, // Ensure 'PostID' is the correct internal field name
            });
          })
          .then(() => {
            console.log(
              `PostID ${postId} updated successfully for ${fileName}`
            );
          })
          .catch((error) => {
            console.error("Error updating PostID:", error);
          });

        // const item = await uploadedFile.file.getItem();
        // await item.update({
        //   PostID: postId, // Ensure this is the correct internal name
        // });
      }

      this.showToast("Post created successfully!");
      await this.loadPostsAndImages();
    } catch (error) {
      this.showToast("Error creating post.");
    }
  }

  /**
   * Renders the toast notification.
   * @returns {React.ReactElement | null} The toast element or null if not visible.
   */
  private renderToast(): React.ReactElement | null {
    return this.state.showToast ? (
      <div className="fixed bottom-4 right-4 bg-green-500 text-white p-4 rounded-md shadow-lg">
        {this.state.toastMessage}
      </div>
    ) : null;
  }

  /**
   * Renders the list of posts.
   */
  private renderPosts(): React.ReactElement {
    return (
      <div className="grid grid-cols-1 gap-4">
        {this.state.posts.length > 0 ? (
          this.state.posts.map((post, index) => (
            <div key={index} className="bg-white shadow-md rounded-lg mb-6">
              <div className="p-4 border-b flex items-center">
                <img
                  src={post.avatarUrl}
                  alt="User Avatar"
                  className="rounded-full w-12 h-12 mr-4"
                />
                <h4 className="text-lg font-bold">{post.user}</h4>
              </div>
              <div className="w-full h-64 overflow-hidden flex justify-center items-center">
                <img
                  src={post.imageUrl}
                  alt={post.title}
                  className="object-cover w-full h-full"
                />
              </div>
              <div className="p-4">
                <p className="text-gray-800">
                  <strong>{post.user}</strong> {post.caption}
                </p>
                <div className="mt-4 flex justify-between">
                  <div className="flex space-x-4">
                    <button className="text-blue-500 flex items-center">
                      <FontAwesomeIcon icon={faThumbsUp} className="m-4" />
                      Like
                    </button>
                    <button className="text-blue-500 flex items-center">
                      <FontAwesomeIcon icon={faComment} className="m-4" />
                      Comment
                    </button>
                  </div>
                  <button className="text-blue-500 flex items-center">
                    <FontAwesomeIcon icon={faShare} className="m-4" />
                    Share
                  </button>
                </div>
              </div>
            </div>
          ))
        ) : (
          <p className="text-gray-500 text-center col-span-full">
            No posts yet.
          </p>
        )}
      </div>
    );
  }

  public render(): React.ReactElement<ISnapAndShareProps> {
    return (
      <div className="container mx-auto p-4">
        <CreatePost onPostCreate={this.handlePostCreate} />
        {/* Add some blank space */}
        {this.renderToast()}
        {this.renderPosts()}
      </div>
    );
  }
}
