/* tslint:disable */
require("./SnapAndShare.module.css");
const styles = {
  snapAndShare: 'snapAndShare_b4dce12f',
  teams: 'teams_b4dce12f',
  welcome: 'welcome_b4dce12f',
  welcomeImage: 'welcomeImage_b4dce12f',
  links: 'links_b4dce12f'
};

export default styles;
/* tslint:enable */