import * as React from "react";
import { ISnapAndShareProps } from "./ISnapAndShareProps";
import "../../../styles/dist/tailwind.css";
interface ISnapAndShareState {
    posts: {
        id: number;
        title: string;
        imageUrl: string;
        caption: string;
        user: string;
        avatarUrl: string;
    }[];
    showToast: boolean;
    toastMessage: string;
}
export default class SnapAndShare extends React.Component<ISnapAndShareProps, ISnapAndShareState> {
    constructor(props: ISnapAndShareProps);
    /**
     * Fetches posts and images from SharePoint lists.
     * Updates the state with posts and their associated images.
     */
    componentDidMount(): void;
    /**
     * Displays a toast message for 3 seconds.
     * @param message - The message to be displayed in the toast.
     */
    private showToast;
    /**
     * Closes the currently open toast message.
     */
    private closeToast;
    /**
     * Loads posts from 'SnapAndSharePosts' list and their images from 'SnapAndShareImages' list.
     * Maps posts with their corresponding images and updates the state.
     */
    private loadPostsAndImages;
    /**
     * Handles creating a new post by uploading images and adding metadata to SharePoint.
     * @param caption - The caption for the post.
     * @param images - The array of images to be uploaded.
     */
    private handlePostCreate;
    /**
     * Renders the toast notification.
     * @returns {React.ReactElement | null} The toast element or null if not visible.
     */
    private renderToast;
    /**
     * Renders the list of posts.
     */
    private renderPosts;
    render(): React.ReactElement<ISnapAndShareProps>;
}
export {};
//# sourceMappingURL=SnapAndShare.d.ts.map