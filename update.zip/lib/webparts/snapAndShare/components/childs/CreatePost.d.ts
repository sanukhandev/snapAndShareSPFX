import * as React from "react";
interface CreatePostProps {
    onPostCreate: (caption: string, images: File[]) => Promise<void>;
}
interface CreatePostState {
    caption: string;
    images: File[];
    isSubmitting: boolean;
    errorMessage: string;
}
export default class CreatePost extends React.Component<CreatePostProps, CreatePostState> {
    constructor(props: CreatePostProps);
    handleCaptionChange(event: React.ChangeEvent<HTMLTextAreaElement>): void;
    handleImageChange(event: React.ChangeEvent<HTMLInputElement>): void;
    handleSubmit(event: React.FormEvent): Promise<void>;
    clearImages(): void;
    /**
     * Renders the caption textarea input.
     */
    private renderCaptionInput;
    /**
     * Renders the image attachment section with the icon.
     */
    private renderImageAttachment;
    /**
     * Renders the submit button.
     */
    private renderSubmitButton;
    /**
     * Renders a preview of the post with the caption and selected images.
     */
    private renderPostPreview;
    /**
     * Renders any error message that might have occurred.
     */
    private renderErrorMessage;
    render(): React.ReactElement<CreatePostProps>;
}
export {};
//# sourceMappingURL=CreatePost.d.ts.map