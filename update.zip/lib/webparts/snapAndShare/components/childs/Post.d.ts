import * as React from 'react';
interface PostProps {
    imageUrl: string;
    caption: string;
    user: string;
}
export default class Post extends React.Component<PostProps> {
    constructor(props: PostProps);
    handleShare(): void;
    render(): React.ReactElement<PostProps>;
}
export {};
//# sourceMappingURL=Post.d.ts.map