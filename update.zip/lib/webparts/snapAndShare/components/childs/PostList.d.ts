import * as React from 'react';
import '../../../styles/dist/tailwind.css';
interface PostListProps {
    posts: {
        imageUrl: string;
        caption: string;
        user: string;
    }[];
}
export default class PostList extends React.Component<PostListProps> {
    constructor(props: PostListProps);
    render(): React.ReactElement<PostListProps>;
}
export {};
//# sourceMappingURL=PostList.d.ts.map