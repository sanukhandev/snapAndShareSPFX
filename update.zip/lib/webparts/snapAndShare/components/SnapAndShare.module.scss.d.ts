declare const styles: {
    snapAndShare: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=SnapAndShare.module.scss.d.ts.map