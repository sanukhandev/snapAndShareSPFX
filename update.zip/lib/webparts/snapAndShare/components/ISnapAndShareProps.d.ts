export interface ISnapAndShareProps {
    description: string;
    isDarkTheme: boolean;
    environmentMessage: string;
    hasTeamsContext: boolean;
    userDisplayName: string;
    context: any;
}
//# sourceMappingURL=ISnapAndShareProps.d.ts.map